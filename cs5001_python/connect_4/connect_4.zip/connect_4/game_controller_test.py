"""Test suite for GameController class"""

from disk import Disk
from board import Board
from game_controller import GameController


def test_game_controller_constructor():
    """Tests game controllor constructor"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    gc = GameController(UI, UNIT_LENGTH)
    assert gc.UNIT_LENGTH == 100 and \
        gc.UI['w'] == 700 and \
        gc.UI['h'] == 700 and \
        gc.board.__class__.__name__ == 'Board' and \
        gc.my_turn is True and \
        gc.disk_buffer == [] and \
        gc.red_wins is False and \
        gc.yellow_wins is False and \
        gc.is_tie is False and \
        gc.scores == {} and \
        gc.show_scores is False and \
        gc.SECTION == 4


def test_winning_rule():
    """Tests winning rule method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    disk_list1 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 1, 1, 1, 1, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0]]

    gc1 = GameController(UI, UNIT_LENGTH)
    assert gc1.winning_rule(disk_list1, 1) == 1

    disk_list2 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 1, 0, 0, 0, 0],
                  [0, 0, 0, 1, 0, 0, 0],
                  [0, 0, 0, 0, 1, 0, 0],
                  [0, 0, 0, 0, 0, 1, 0]]

    gc2 = GameController(UI, UNIT_LENGTH)
    assert gc2.winning_rule(disk_list2, 1) == 1

    disk_list3 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 2, 0, 0, 0, 0, 0],
                  [0, 0, 2, 0, 0, 0, 0],
                  [0, 0, 0, 2, 0, 0, 0],
                  [0, 0, 0, 0, 2, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0]]

    gc3 = GameController(UI, UNIT_LENGTH)
    assert gc3.winning_rule(disk_list3, 2) == 2

    disk_list4 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 2],
                  [0, 0, 0, 0, 0, 2, 0],
                  [0, 0, 0, 0, 2, 0, 0],
                  [0, 0, 0, 2, 0, 0, 0]]

    gc4 = GameController(UI, UNIT_LENGTH)
    assert gc4.winning_rule(disk_list4, 2) == 2

    disk_list5 = [[1, 1, 1, 2, 1, 1, 1],
                  [2, 2, 2, 1, 2, 2, 2],
                  [1, 1, 1, 2, 1, 1, 1],
                  [2, 2, 2, 1, 2, 2, 2],
                  [1, 1, 1, 2, 1, 1, 1],
                  [2, 2, 2, 1, 2, 2, 2]]

    gc5 = GameController(UI, UNIT_LENGTH)
    assert gc5.winning_rule(disk_list5) == -1

    disk_list6 = [[1, 1, 1, 0, 1, 1, 1],
                  [2, 2, 2, 1, 2, 2, 2],
                  [1, 1, 1, 2, 1, 1, 1],
                  [2, 2, 2, 1, 2, 2, 2],
                  [1, 1, 1, 2, 1, 1, 1],
                  [2, 2, 2, 1, 2, 2, 2]]

    gc6 = GameController(UI, UNIT_LENGTH)
    assert gc6.winning_rule(disk_list6) is None

    disk_list7 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 1, 0, 0, 0],
                  [0, 0, 0, 1, 1, 1, 0],
                  [0, 0, 0, 1, 0, 0, 0],
                  [0, 0, 0, 1, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0]]

    gc7 = GameController(UI, UNIT_LENGTH)
    assert gc7.winning_rule(disk_list7, 1) == 1


def test_check_win():
    """Tests check win method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    b1 = Board(UI, UNIT_LENGTH)
    b1.disk_list = [[0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 1, 1, 1, 1, 0],
                    [0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0]]

    gc1 = GameController(UI, UNIT_LENGTH)
    gc1.check_win(b1)
    assert gc1.red_wins is True and \
           gc1.yellow_wins is False and \
           gc1.is_tie is False

    b2 = Board(UI, UNIT_LENGTH)
    b2.disk_list = [[0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0],
                    [0, 0, 1, 0, 0, 0, 0],
                    [0, 0, 0, 1, 0, 0, 0],
                    [0, 0, 0, 0, 1, 0, 0],
                    [0, 0, 0, 0, 0, 1, 0]]

    gc2 = GameController(UI, UNIT_LENGTH)
    gc2.check_win(b2)
    assert gc2.red_wins is True and \
           gc2.yellow_wins is False and \
           gc2.is_tie is False

    b3 = Board(UI, UNIT_LENGTH)
    b3.disk_list = [[0, 0, 0, 0, 0, 0, 0],
                    [0, 2, 0, 0, 0, 0, 0],
                    [0, 0, 2, 0, 0, 0, 0],
                    [0, 0, 0, 2, 0, 0, 0],
                    [0, 0, 0, 0, 2, 0, 0],
                    [0, 0, 0, 0, 0, 0, 0]]

    gc3 = GameController(UI, UNIT_LENGTH)
    gc3.check_win(b3)
    assert gc3.red_wins is False and \
           gc3.yellow_wins is True and \
           gc3.is_tie is False

    b5 = Board(UI, UNIT_LENGTH)
    b5.disk_list = [[1, 1, 1, 2, 1, 1, 1],
                    [2, 2, 2, 1, 2, 2, 2],
                    [1, 1, 1, 2, 1, 1, 1],
                    [2, 2, 2, 1, 2, 2, 2],
                    [1, 1, 1, 2, 1, 1, 1],
                    [2, 2, 2, 1, 2, 2, 2]]

    gc5 = GameController(UI, UNIT_LENGTH)
    gc5.check_win(b5)
    assert gc5.red_wins is False and \
           gc5.yellow_wins is False and \
           gc5.is_tie is True

    b6 = Board(UI, UNIT_LENGTH)
    b6.disk_list = [[1, 1, 1, 0, 1, 1, 1],
                    [2, 2, 2, 1, 2, 2, 2],
                    [1, 1, 1, 2, 1, 1, 1],
                    [2, 2, 2, 1, 2, 2, 2],
                    [1, 1, 1, 2, 1, 1, 1],
                    [2, 2, 2, 1, 2, 2, 2]]

    gc6 = GameController(UI, UNIT_LENGTH)
    gc6.check_win(b6)
    assert gc6.red_wins is False and \
           gc6.yellow_wins is False and \
           gc6.is_tie is False


def test_sorted_score():
    """Tests sorted score method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    gc = GameController(UI, UNIT_LENGTH)
    gc.scores = {"a": 3, "b": 7, "c": 2}
    assert gc.sorted_score(gc.scores) == [("b", 7), ("a", 3), ("c", 2)]


def test_get_move_score():
    """Tests get move score method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    disk_list1 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 1, 1, 1, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0]]

    gc1 = GameController(UI, UNIT_LENGTH)
    assert gc1.get_move_score(disk_list1, 2, 1) == 100

    disk_list2 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 1, 0, 0, 0, 0],
                  [0, 0, 0, 1, 0, 0, 0],
                  [0, 0, 0, 0, 1, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0]]

    gc2 = GameController(UI, UNIT_LENGTH)
    assert gc2.get_move_score(disk_list2, 5, 5) == 100

    disk_list3 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 2, 0, 0, 0, 0],
                  [0, 0, 0, 2, 0, 0, 0],
                  [0, 0, 0, 0, 2, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0]]

    gc3 = GameController(UI, UNIT_LENGTH)
    assert gc3.get_move_score(disk_list3, 5, 5) == 200

    disk_list4 = [[0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 0, 0, 0],
                  [0, 0, 0, 0, 1, 0, 0],
                  [0, 1, 0, 0, 2, 2, 0]]

    gc4 = GameController(UI, UNIT_LENGTH)
    assert gc4.get_move_score(disk_list4, 5, 3) == 15
    assert gc4.get_move_score(disk_list4, 5, 6) == 15


def test_score_rule():
    """Tests score rule method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    gc1 = GameController(UI, UNIT_LENGTH)
    window1 = [0, 0, 0, 0]
    assert gc1.score_rule(window1) == 5

    gc2 = GameController(UI, UNIT_LENGTH)
    window2 = [2, 2, 2, 0]
    assert gc2.score_rule(window2) == 200

    gc3 = GameController(UI, UNIT_LENGTH)
    window3 = [0, 1, 1, 1]
    assert gc3.score_rule(window3) == 100

    gc4 = GameController(UI, UNIT_LENGTH)
    window1 = [0, 2, 2, 0]
    assert gc4.score_rule(window1) == 15

    gc5 = GameController(UI, UNIT_LENGTH)
    window5 = [0, 2, 1, 0]
    assert gc5.score_rule(window5) == 10


def test_pick_next_move():
    """Tests pick next move method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    gc1 = GameController(UI, UNIT_LENGTH)
    gc1.board.disk_list = [[0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 2, 2, 2]]
    assert gc1.pick_next_move(gc1.board) == 3

    gc3 = GameController(UI, UNIT_LENGTH)
    gc3.board.disk_list = [[0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 1, 0, 0, 0, 0],
                           [0, 0, 1, 0, 0, 0, 0],
                           [0, 0, 1, 0, 0, 0, 0]]
    assert gc3.pick_next_move(gc3.board) == 2

    gc5 = GameController(UI, UNIT_LENGTH)
    gc5.board.disk_list = [[0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 1, 0, 0, 0, 0],
                           [0, 0, 1, 0, 0, 0, 0],
                           [0, 0, 1, 2, 2, 2, 0]]
    assert gc5.pick_next_move(gc5.board) == 6
