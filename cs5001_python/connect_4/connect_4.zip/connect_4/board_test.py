"""Test suite for Board class"""

from board import Board


def test_board_constructor():
    """Tests board constructor"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    b = Board(UI, UNIT_LENGTH)
    assert b.UI['w'] == 700 and \
        b.UI['h'] == 700 and \
        b.UNIT_LENGTH == 100 and \
        b.ROW == 6 and \
        b.COLUMN == 7 and \
        b.disk_list == [[0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0]]

    UI = {'w': 200, 'h': 300}
    b_mini = Board(UI, UNIT_LENGTH, 'mini')
    assert b_mini.UI['w'] == 200 and \
        b_mini.UI['h'] == 300 and \
        b_mini.UNIT_LENGTH == 100 and \
        b_mini.ROW == 2 and \
        b_mini.COLUMN == 2 and \
        b_mini.disk_list == [[0, 0], [0, 0]]


def test_find_stop_row():
    """Tests find_stop_row method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    disk_list1 = [[0, 0, 0, 2, 0, 0, 0],
                  [0, 0, 0, 2, 0, 0, 0],
                  [0, 0, 0, 2, 0, 0, 0],
                  [0, 0, 0, 2, 0, 0, 0],
                  [0, 0, 2, 2, 0, 0, 0],
                  [0, 1, 2, 1, 0, 0, 0]]
    b = Board(UI, UNIT_LENGTH)

    assert b.find_stop_row(disk_list1, 0) == 5
    assert b.find_stop_row(disk_list1, 1) == 4
    assert b.find_stop_row(disk_list1, 2) == 3
    assert b.find_stop_row(disk_list1, 3) == -1


def test_find_column():
    """Tests find_column method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    b = Board(UI, UNIT_LENGTH)
    mouseX = 350
    mouseY = 50
    assert b.find_column(mouseX, mouseY) == 3
    mouseX = 350
    mouseY = 200
    assert b.find_column(mouseX, mouseY) is None


def test_reset_board():
    """Tests reset board method"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    b = Board(UI, UNIT_LENGTH)
    b.disk_list = [[0, 0, 0, 2, 0, 0, 0],
                   [0, 0, 0, 2, 0, 0, 0],
                   [0, 0, 0, 2, 0, 0, 0],
                   [0, 0, 0, 2, 0, 0, 0],
                   [0, 0, 2, 2, 0, 0, 0],
                   [0, 1, 2, 1, 0, 0, 0]]
    b.reset_board()
    assert b.disk_list == [[0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0],
                           [0, 0, 0, 0, 0, 0, 0]]
