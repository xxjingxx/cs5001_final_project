"""Test suite for Disk class"""
from disk import Disk


def test_disk_constructor():
    """Tests disk constructor"""
    UI = {'w': 700, 'h': 700}
    UNIT_LENGTH = 100

    d = Disk(UI, UNIT_LENGTH)
    assert d.UI['w'] == 700 and \
        d.UI['h'] == 700 and \
        d.UNIT_LENGTH == 100 and \
        d.DIAMETER == 90 and \
        d.YELLOW == (1.0, 1.0, 0) and \
        d.RED == (1.0, 0, 0) and \
        d.y_vel == 0 and \
        d.y == 50 and \
        d.column == 0 and \
        d.color == 'red' and \
        d.napTime == 20000000
